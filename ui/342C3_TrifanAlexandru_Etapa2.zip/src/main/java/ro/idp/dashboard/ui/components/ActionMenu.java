package ro.idp.dashboard.ui.components;

import ro.idp.dashboard.ui.components.events.EventMessage;
import ro.idp.dashboard.ui.components.events.Events;
import ro.idp.dashboard.ui.components.events.MyEvent;
import ro.idp.dashboard.ui.components.events.MyEventListener;

import javax.swing.*;
import javax.swing.event.EventListenerList;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

/**
 * Created by Enti on 2/24/2016.
 */
public class ActionMenu extends JPanel{

    private JTree actions;
    private DefaultMutableTreeNode rootNode = new DefaultMutableTreeNode("right-click");
    private DefaultTreeModel treeModel;
    private String groupName;

    public ActionMenu(String groupName) {
        //TODO: pass also the current user
        this.groupName = groupName;
        initUI(groupName);
        initActions();
    }

    private void initUI(String groupName) {
        setSize(240, 120);
        setLayout(null);
        treeModel = new DefaultTreeModel(rootNode);
        actions = new JTree(treeModel);
        actions.getSelectionModel().setSelectionMode
                (TreeSelectionModel.SINGLE_TREE_SELECTION);
        actions.setRootVisible(false);
        JScrollPane scrollPane = new JScrollPane(actions);
        scrollPane.setBounds(9, 9, 240 - 18, 120 - 18);
        add(scrollPane);
        setVisible(true);
        addAddUserOption(groupName);
        addJoinGroupOption(groupName);
    }

    private void addAddUserOption(String groupName) {
        DefaultMutableTreeNode addUser = new DefaultMutableTreeNode("Add User");
        for(String userName : getUsers(groupName)) {
            DefaultMutableTreeNode userNode = new DefaultMutableTreeNode(userName);
            addUser.add(userNode);
        }
        treeModel.insertNodeInto(addUser, rootNode, rootNode.getChildCount());
        actions.expandPath(new TreePath(addUser.getPath()));
    }

    private ArrayList<String> getUsers(String group) {
        ArrayList<String> users = new ArrayList<>();
        users.add(group + "_user1");
        return users;
    }

    private void addJoinGroupOption(String groupName) {
        DefaultMutableTreeNode joinGroup = new DefaultMutableTreeNode("Join Group");
        DefaultMutableTreeNode theGroup = new DefaultMutableTreeNode(groupName);
        joinGroup.add(theGroup);
        treeModel.insertNodeInto(joinGroup, rootNode, rootNode.getChildCount());
        actions.expandPath(new TreePath(joinGroup.getPath()));
    }

    private void initActions() {
        actions.addMouseListener(menuAction());
    }

    private MouseAdapter menuAction() {
        MouseAdapter mouseAdapter = new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                if (SwingUtilities.isLeftMouseButton(e)) {
                    TreePath path = actions.getPathForLocation(e.getX(), e.getY());
                    if(path.getPathCount() == 3) {
                        triggerAction(path);
                    }
                }
            }
        };
        return mouseAdapter;
    }

    private void triggerAction(TreePath path) {
        DefaultMutableTreeNode node = (DefaultMutableTreeNode) path.getLastPathComponent();
        String actionName = (String) ((DefaultMutableTreeNode) node.getParent()).getUserObject(),
            actor = (String) node.getUserObject();

        if(actionName.equals("Add User")) {
            EventMessage event = new EventMessage();
            event.setData("group", this.groupName);
            event.setData("user", actor);
            event.setEventType(Events.ADD_USER);
            fireMyEvent(new MyEvent(event));
        }
    }

    protected EventListenerList listenerList = new EventListenerList();

    public void addMyEventListener(MyEventListener listener) {
        listenerList.add(MyEventListener.class, listener);
    }
    public void removeMyEventListener(MyEventListener listener) {
        listenerList.remove(MyEventListener.class, listener);
    }
    void fireMyEvent(MyEvent evt) {
        Object[] listeners = listenerList.getListenerList();
        for (int i = 0; i < listeners.length; i = i+2) {
            if (listeners[i] == MyEventListener.class) {
                ((MyEventListener) listeners[i+1]).myEventOccurred(evt);
            }
        }
    }
}
