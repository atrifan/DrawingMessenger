package ro.idp.dashboard.ui.components;

import ro.idp.dashboard.ui.components.events.EventMessage;
import ro.idp.dashboard.ui.components.events.Events;
import ro.idp.dashboard.ui.components.events.MyEvent;
import ro.idp.dashboard.ui.components.events.MyEventListener;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.event.EventListenerList;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by Enti on 2/23/2016.
 */
public class Login extends JPanel{

    private JLabel labelUsername = new JLabel("Enter username: ");
    private JLabel labelPassword = new JLabel("Enter password: ");
    private JTextField textUsername = new JTextField();
    private JPasswordField fieldPassword = new JPasswordField();
    private JButton buttonLogin = new JButton("Login");
    private JLabel scenetitle = new JLabel("Login");
    final JLabel actiontarget = new JLabel();

    protected EventListenerList listenerList = new EventListenerList();

    public void addMyEventListener(MyEventListener listener) {
        listenerList.add(MyEventListener.class, listener);
    }
    public void removeMyEventListener(MyEventListener listener) {
        listenerList.remove(MyEventListener.class, listener);
    }
    void fireMyEvent(MyEvent evt) {
        Object[] listeners = listenerList.getListenerList();
        for (int i = 0; i < listeners.length; i = i+2) {
            if (listeners[i] == MyEventListener.class) {
                ((MyEventListener) listeners[i+1]).myEventOccurred(evt);
            }
        }
    }

    public Login() {
        initActions();
        initUI();
    }

    private void initActions() {
        buttonLogin.addActionListener(this.login());
    }

    private ActionListener login() {
        ActionListener handler = new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if(isFormValid()) {
                    actiontarget.setVisible(false);
                    EventMessage message = new EventMessage();
                    message.setEventType(Events.LOGIN);
                    message.setData("userName", textUsername.getText());
                    MyEvent event = new MyEvent(message);
                    fireMyEvent(event);
                } else {
                    actiontarget.setText("Please fill all form data");
                    actiontarget.setVisible(true);
                }
            }
        };

        return handler;
    }

    private CompoundBorder getBlackBorder() {
        Border line = BorderFactory.createLineBorder(Color.DARK_GRAY);
        Border empty = new EmptyBorder(0, 9, 0, 0);
        CompoundBorder border = new CompoundBorder(line, empty);
        return border;
    }

    private CompoundBorder getRedBorder() {
        Border line = BorderFactory.createLineBorder(Color.RED);
        Border empty = new EmptyBorder(0, 9, 0, 0);
        CompoundBorder border = new CompoundBorder(line, empty);
        return border;
    }

    public void initUI() {
        setLayout(null);
        add(scenetitle);
        scenetitle.setFont(new Font("Tahoma", Font.BOLD, 20));

        /**POSITIONS**/
        setSize(360, 240);
        scenetitle.setBounds(10, 20, 120, 30);
        labelUsername.setBounds(10, 60, 120, 20);
        textUsername.setBounds(150, 60, 200, 20);
        textUsername.setBorder(getBlackBorder());
        labelPassword.setBounds(10, 90, 120, 20);
        fieldPassword.setBounds(150, 90, 200, 20);
        fieldPassword.setBorder(getBlackBorder());
        buttonLogin.setBounds(280, 140, 70, 20);
        actiontarget.setBounds(220, 170, 130, 20);
        actiontarget.setVisible(false);
        actiontarget.setForeground(Color.RED);

        add(labelUsername);
        add(textUsername);
        add(labelPassword);
        add(fieldPassword);
        add(buttonLogin);
        add(actiontarget);
    }

    protected boolean isFormValid() {
        String userName = textUsername.getText(),
                password = fieldPassword.getText();

        boolean valid = true;
        if(userName.isEmpty()) {
            valid = false;
            textUsername.setBorder(getRedBorder());
        } else {
            textUsername.setBorder(getBlackBorder());
        }

        if(password.isEmpty()) {
            valid = false;
            fieldPassword.setBorder(getRedBorder());
        } else {
            fieldPassword.setBorder(getBlackBorder());
        }

        return valid;
    }
}
