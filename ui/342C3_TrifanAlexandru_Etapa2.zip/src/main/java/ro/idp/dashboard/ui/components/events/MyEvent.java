package ro.idp.dashboard.ui.components.events;

import java.util.EventObject;

/**
 * Created by Enti on 2/24/2016.
 */
public class MyEvent extends EventObject {
    public MyEvent(EventMessage source) {
        super(source);
    }
}

