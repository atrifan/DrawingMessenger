package ro.idp.dashboard.ui.components;

import javax.swing.*;

/**
 * Created by Enti on 2/23/2016.
 */
public class Drawer extends JPanel {
    private DrawArea drawArea = new DrawArea();
    private Chat myChat = new Chat();

    public Drawer() {
        initUI();
    }

    private void initUI() {
        setSize(400, 500);
        setLayout(null);
        drawArea.setBounds(0, 0, drawArea.getWidth(), drawArea.getHeight());
        myChat.setBounds(0, getHeight() - myChat.getHeight(), myChat.getWidth(), myChat.getHeight());
        add(myChat);
        add(drawArea);
        setVisible(true);
    }
}
