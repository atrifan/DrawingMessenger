package ro.idp.dashboard.ui.components.events;

/**
 * Created by Enti on 2/24/2016.
 */
public enum Events {
    LOGIN,
    SHAPE,
    ADD_USER
}
