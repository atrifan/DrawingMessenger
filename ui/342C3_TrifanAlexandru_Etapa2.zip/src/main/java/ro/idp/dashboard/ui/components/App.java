package ro.idp.dashboard.ui.components;

import ro.idp.dashboard.ui.components.events.EventMessage;
import ro.idp.dashboard.ui.components.events.MyEvent;
import ro.idp.dashboard.ui.components.events.MyEventListener;

import javax.swing.*;
import java.util.Map;

/**
 * Created by Enti on 2/23/2016.
 */
public class App extends JFrame {

    public App() {
        initLoginUI();
    }

    UserPanel userPanel;
    GroupPanel groupPanel;
    MyGroups myGroups;
    Toolbar toolbar;
    Drawer drawer;


    private void initLoginUI() {
        Login loginView = new Login();
        setSize(800, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        loginView.setAlignmentX(400 - loginView.getHeight() / 2);
        loginView.setAlignmentY(300 - loginView.getWidth() / 2);
        getContentPane().setLayout(null);
        getContentPane().add(loginView);
        setTitle("DashBoard");
        setVisible(true);
        int panelX = (getWidth() - loginView.getWidth() - getInsets().left - getInsets().right) / 2;
        int panelY = ((getHeight() - loginView.getHeight() - getInsets().top - getInsets().bottom) / 2);
        loginView.setLocation(panelX, panelY);
        loginView.addMyEventListener(treatEvent());
    }

    private MyEventListener treatEvent() {
        MyEventListener myEvent = new MyEventListener() {
            @Override
            public void myEventOccurred(MyEvent evt) {
                EventMessage eventMessage = (EventMessage) evt.getSource();
                switch (eventMessage.getEventType()) {
                    case LOGIN :
                        initAppUI(eventMessage.getData());
                        break;
                    default:
                        break;
                }
            }
        };
        return myEvent;
    }

    private void refresh() {
        invalidate();
        validate();
        repaint();
    }
    private void initAppUI(Map<String, String> data) {
        getContentPane().remove(0);
        toolbar = new Toolbar(data.get("userName"));
        userPanel = new UserPanel();
        groupPanel = new GroupPanel();
        myGroups = new MyGroups();
        drawer = new Drawer();
        setPositionOfToolbar();
        setPositionOfUserPanel();
        setPositionOfGroupPanel();
        setPositionOfMyGroups();
        setPositionOfDrawer();
        getContentPane().add(toolbar);
        getContentPane().add(userPanel);
        getContentPane().add(groupPanel);
        getContentPane().add(myGroups);
        getContentPane().add(drawer);
        refresh();
        groupPanel.addGroup("Test");
        groupPanel.addGroup("Jax");
    }

    private void setPositionOfDrawer() {
        int yPosition = myGroups.getY() + myGroups.getHeight() + 10,
            xPosition = myGroups.getX();
        System.out.println(yPosition);
        drawer.setBounds(xPosition, yPosition, drawer.getWidth(), drawer.getHeight());
    }

    private void setPositionOfToolbar() {
        System.out.println(toolbar.getWidth());
        int leftAlignment = getWidth() - toolbar.getWidth() - 10,
            topAlignment = 10,
            width = toolbar.getWidth(),
            height = toolbar.getHeight();
        toolbar.setBounds(leftAlignment, topAlignment, width, height);
    }
    private void setPositionOfUserPanel() {
        userPanel.setBounds(10, 10, userPanel.getWidth(), userPanel.getHeight());
    }
    private void setPositionOfGroupPanel() {
        groupPanel.setBounds(10, userPanel.getHeight() + 10, groupPanel.getWidth(), groupPanel.getHeight());
    }

    private void setPositionOfMyGroups() {
        myGroups.setBounds(toolbar.getX() - 20, toolbar.getY() + toolbar.getHeight(), myGroups.getWidth(),
                myGroups.getHeight());
    }

}

