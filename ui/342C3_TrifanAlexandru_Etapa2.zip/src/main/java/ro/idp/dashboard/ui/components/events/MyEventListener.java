package ro.idp.dashboard.ui.components.events;

import java.util.EventListener;

/**
 * Created by Enti on 2/24/2016.
 */
public interface MyEventListener extends EventListener {
    public void myEventOccurred(MyEvent evt);
}