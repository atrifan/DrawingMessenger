package ro.idp.dashboard.ui.components;

import javax.swing.*;
import java.util.ArrayList;

/**
 * Created by Enti on 2/24/2016.
 */
public class MyGroups extends JPanel {

    JTabbedPane myGroups;
    public MyGroups() {
        initUI();
    }

    private void initUI() {
        setSize(400, 20);
        myGroups = new JTabbedPane();
        setLayout(null);
        setVisible(true);
        myGroups.setBounds(5, 0, 395, 20);
        add(myGroups);
        addMyGroups();
    }

    private void addMyGroups() {
        //TODO: via userName
        for(String group : getGroups()) {
            JButton button = new JButton(group);
            myGroups.addTab(group, new ImageIcon("yourFile.gif"), button, group);
        }
    }

    private ArrayList<String> getGroups() {
        ArrayList<String> result = new ArrayList<>();
        result.add("Group 1");
        result.add("Group 2");
        return result;
    }
}
