package ro.idp.dashboard.ui.components;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Rectangle2D;

/**
 * Created by Enti on 2/24/2016.
 */
public class DrawArea extends JPanel {
    private JButton square = new JButton("[]"),
            circle = new JButton("()"),
            arrow = new JButton("->"),
            line = new JButton("/");

    PaintSurface drawArea = new PaintSurface();
    private JPanel legend = new JPanel();
    private Point startDrag,
                endDrag;

    public DrawArea() {
        initUI();
        initDrawingButtons();
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
    }


    private void initUI() {
        setSize(400, 230);
        setLayout(null);
        setDrawingButtonsPosition();
        add(square);
        add(circle);
        add(arrow);
        add(line);

        setDrawingArea();
        add(drawArea);

        setLegend();
        add(legend);
        setVisible(true);
    }

    private void setDrawingArea() {
        drawArea.setBounds(0, 30, 300, 200);
        drawArea.setBackground(Color.WHITE);
    }

    private void setLegend() {
        legend.setBounds(310, 30, 90, 200);
        JLabel legendLabel = new JLabel("Legend");
        legend.add(legendLabel);
    }

    private void setDrawingButtonsPosition() {
        square.setBounds(0, 0, 60, 20);
        circle.setBounds(70, 0, 60, 20);
        arrow.setBounds(140, 0, 60, 20);
        line.setBounds(210, 0, 60, 20);
    }

    public void initDrawingButtons() {
        square.setActionCommand("rectangle");
        circle.setActionCommand("circle");
        arrow.setActionCommand("arrow");
        line.setActionCommand("line");
        square.addActionListener(setDrawingType());
        circle.addActionListener(setDrawingType());
        arrow.addActionListener(setDrawingType());
        line.addActionListener(setDrawingType());
    }

    private void enableButtons() {
        square.setEnabled(true);
        circle.setEnabled(true);
        arrow.setEnabled(true);
        line.setEnabled(true);
    }
    private ActionListener setDrawingType() {
        ActionListener actionListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                enableButtons();
                JButton presedButton = (JButton) e.getSource();
                presedButton.setEnabled(false);
                drawArea.setShape(ShapeSelection.fromString(e.getActionCommand()));
            }
        };
        return actionListener;
    }
}
