package ro.idp.dashboard.ui.app;

import ro.idp.dashboard.ui.components.App;

/**
 * Created by Enti on 2/23/2016.
 */
public class Main {
    public static void main(String[] args) {
        App app = new App();
    }
}
