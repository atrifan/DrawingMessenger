package ro.idp.dashboard.ui.components;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Date;

/**
 * Created by Enti on 2/23/2016.
 */
public class Chat extends JPanel {
    private JLabel fontLabel = new JLabel("Font"),
        colorLabel = new JLabel("Color");

    private JComboBox font = new JComboBox(),
        color = new JComboBox();

    private JTextPane messages = new JTextPane();
    private JTextField messageWriter = new JTextField();
    private JScrollPane messagesScroll;

    private JButton sendButton = new JButton("Send");

    public Chat() {
        initUI();
        initActions();
    }

    private void initUI() {
        setSize(400, 260);
        setLayout(null);
        messages.setBorder(setPadding(10));
        messages.setEditable(false);
        messageWriter.setBorder(setPadding(10));
        messagesScroll = new JScrollPane(messages);
        setPositionOfMessages();
        setPositionOfTextProperties();
        setPositionOfTextWritter();
        setPositionOfSendButton();
        setFontOptions();
        setColorOptions();
        add(messagesScroll);
        add(messageWriter);
        add(sendButton);
        add(font);
        add(fontLabel);
        add(color);
        add(colorLabel);
        setVisible(true);
    }

    private void initActions() {
        sendButton.addActionListener(this.sendMessage());
    }

    private void setColorOptions() {
        Field[] declaredFields = Color.class.getDeclaredFields();
        ArrayList<Field> staticFields = new ArrayList<Field>();
        for (Field field : declaredFields) {
            if (java.lang.reflect.Modifier.isStatic(field.getModifiers())) {
                staticFields.add(field);
            }
        }

        for(Field colorField : staticFields) {
            if(colorField.getName().toUpperCase().equals(colorField.getName())) {
                color.addItem(colorField.getName());
            }
        }
    }

    private Color getColorByString(String color) {
        Class  aClass = Color.class;
        Field field = null;
        try {
            field = aClass.getField(color);
            Color value = (Color)field.get(null);
            return value;
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }

        return null;
    }

    private void setFontOptions() {
        String[] fonts = {"12", "14", "16", "18", "20", "22", "24"};
        for(int i = 0; i < fonts.length; i++) {
            font.addItem(fonts[i]);
        }
    }

    private CompoundBorder setPadding(int size) {
        Border line = BorderFactory.createLineBorder(Color.GRAY);
        Border empty = new EmptyBorder(0, size, 0, 0);
        CompoundBorder border = new CompoundBorder(line, empty);
        return border;
    }

    private void setPositionOfMessages() {
        messagesScroll.setBounds(0, 0, getWidth(), 180);
    }

    private void setPositionOfTextProperties() {
        fontLabel.setBounds(0, 190, 40, 20);
        font.setBounds(60, 190, 40, 20);
        colorLabel.setBounds(120, 190, 40, 20);
        color.setBounds(180, 190, 100, 20);
    }

    private void setPositionOfTextWritter() {
        messageWriter.setBounds(0, 230, 290, 20);
    }

    private void setPositionOfSendButton() {
        sendButton.setBounds(330, 230, 70, 20);
    }

    private ActionListener sendMessage() {
        ActionListener handler = new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                String message = messageWriter.getText();
                int fontSize = Integer.parseInt(font.getSelectedItem().toString());
                Color selectedColor = getColorByString(color.getSelectedItem().toString());
                messageWriter.setText("");
                StyledDocument doc = messages.getStyledDocument();
                StyleContext context = new StyleContext();
                Style style = context.addStyle((new Date()).getTime() + "", null);
                StyleConstants.setForeground(style, selectedColor);
                StyleConstants.setFontSize(style, fontSize);
                try {
                    doc.insertString(doc.getLength(), message + "\n", style);
                } catch (BadLocationException e1) {
                    e1.printStackTrace();
                }
            }
        };

        return handler;
    }
}
