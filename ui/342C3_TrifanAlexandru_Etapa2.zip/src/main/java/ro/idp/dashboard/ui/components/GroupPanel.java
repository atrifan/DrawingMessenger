package ro.idp.dashboard.ui.components;

import ro.idp.dashboard.ui.components.events.EventMessage;
import ro.idp.dashboard.ui.components.events.MyEvent;
import ro.idp.dashboard.ui.components.events.MyEventListener;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

/**
 * Created by Enti on 2/23/2016.
 */
public class GroupPanel extends JPanel {

    private DefaultMutableTreeNode rootNode = new DefaultMutableTreeNode("groups");
    private DefaultTreeModel treeModel;
    private JTree groups;

    public GroupPanel() {
        initUI();
        setMouseListener();
    }

    private void setMouseListener() {
        groups.addMouseListener(groupAction());
    }

    private MouseAdapter groupAction() {
        MouseAdapter mouseAdapter = new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                if (SwingUtilities.isRightMouseButton(e)) {
                    TreePath path = groups.getPathForLocation(e.getX(), e.getY());
                    if(path.getPathCount() == 2) {
                        showGroupActions(e, path);
                    }
                }
            }
        };
        return mouseAdapter;
    }

    private MyEventListener treatEvent() {
        MyEventListener myEvent = new MyEventListener() {
            @Override
            public void myEventOccurred(MyEvent evt) {
                EventMessage eventMessage = (EventMessage) evt.getSource();
                switch (eventMessage.getEventType()) {
                    case ADD_USER:
                        addUser(eventMessage.getData().get("group"), eventMessage.getData().get("user"));
                        break;
                    default:
                        break;
                }
            }
        };
        return myEvent;
    }


    private void showGroupActions(MouseEvent e, TreePath path) {
        Rectangle pathBounds = groups.getUI().getPathBounds(groups, path);
        DefaultMutableTreeNode node = (DefaultMutableTreeNode) path.getLastPathComponent();
        ActionMenu actionMenu = new ActionMenu((String) node.getUserObject());
        actionMenu.addMyEventListener(treatEvent());
        if (pathBounds != null && pathBounds.contains(e.getX(), e.getY())) {
            JPopupMenu menu = new JPopupMenu();
            menu.add(actionMenu);
            menu.show(groups, pathBounds.x + pathBounds.width, pathBounds.y + pathBounds.height);
        }
    }

    private void initUI() {
        setSize(300, 380);
        treeModel = new DefaultTreeModel(rootNode);
        groups = new JTree(treeModel);
        groups.getSelectionModel().setSelectionMode
                (TreeSelectionModel.SINGLE_TREE_SELECTION);
        groups.setRootVisible(false);
        JScrollPane scrollPane = new JScrollPane(groups);
        scrollPane.setBounds(10, 10, 290, 360);
        add(scrollPane);
        setLayout(null);
        setVisible(true);
    }

    public void addGroups(ArrayList<String> groupNames) {
        for(String group : groupNames) {
            addGroup(group);
        }
    }

    private ArrayList<String> getUsers(String groupName) {
        ArrayList<String> users = new ArrayList<>();
        users.add(groupName + "_user1");
        return users;
    }

    public void addGroup(String groupName) {
        DefaultMutableTreeNode groupNode = new DefaultMutableTreeNode(groupName);
        for(String user : getUsers(groupName)) {
            DefaultMutableTreeNode userNode = new DefaultMutableTreeNode(user);
            groupNode.add(userNode);
        }
        treeModel.insertNodeInto(groupNode, rootNode, rootNode.getChildCount());
        //groups.scrollPathToVisible(new TreePath(groupNode.getPath()));
        groups.expandPath(new TreePath(groupNode.getPath()));
    }

    public void addUser(String group, String user) {

        int noChildren = treeModel.getChildCount(rootNode);
        System.out.println(group + " " + user + " " + noChildren);
        for(int i = 0; i < noChildren; i++) {
            DefaultMutableTreeNode node = (DefaultMutableTreeNode) treeModel.getChild(rootNode, i);
            if(node.getUserObject().toString().equals(group)) {
                node.add(new DefaultMutableTreeNode(user));
                treeModel.reload(node);
                groups.expandPath(new TreePath(node.getPath()));
                break;
            }
        }
        //refresh();
    }


    private void refresh() {
        invalidate();
        validate();
        repaint();
    }
}
