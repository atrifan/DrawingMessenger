package ro.idp.dashboard.ui.components;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.geom.*;
import java.util.ArrayList;

/**
 * Created by Enti on 2/27/2016.
 */
public class PaintSurface extends JComponent {
    ArrayList<Shape> shapes = new ArrayList<Shape>();

    Point startDrag, endDrag;
    ShapeSelection shape = null;

    public PaintSurface() {
        setBackground(Color.WHITE);
        this.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                if(shape == null) {
                    return;
                }
                startDrag = new Point(e.getX(), e.getY());
                endDrag = startDrag;
                repaint();
            }

            public void mouseReleased(MouseEvent e) {
                if(shape == null) {
                    return;
                }
                Object r = makeShape(startDrag.x, startDrag.y, e.getX(), e.getY());
                if(r instanceof Shape) {
                    shapes.add((Shape) r);
                } else {
                    for(Shape s : (ArrayList<Shape>)r) {
                        shapes.add(s);
                    }
                }
                startDrag = null;
                endDrag = null;
                repaint();
            }
        });

        this.addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent e) {
                if(shape == null) {
                    return;
                }
                endDrag = new Point(e.getX(), e.getY());
                repaint();
            }
        });
    }

    public void setShape(ShapeSelection shape) {
        this.shape = shape;
    }

    private void paintBackground(Graphics2D g2){
        Shape background = makeRectangle(0, 0, getSize().width - 10, getSize().height - 10);
        g2.setPaint(Color.WHITE);
        g2.fill(background);
        /*for (int i = 0; i < getSize().width; i += 10) {
            Shape line = new Line2D.Float(i, 0, i, getSize().height);
            g2.draw(line);
        }

        for (int i = 0; i < getSize().height; i += 10) {
            Shape line = new Line2D.Float(0, i, getSize().width, i);
            g2.draw(line);
        }*/
    }
    public void paint(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        paintBackground(g2);
        Color[] colors = { Color.YELLOW, Color.MAGENTA, Color.CYAN , Color.RED, Color.BLUE, Color.PINK};
        int colorIndex = 0;

        g2.setStroke(new BasicStroke(2));
        g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.50f));

        for (Shape s : shapes) {
            g2.setPaint(Color.BLACK);
            g2.draw(s);
            g2.setPaint(colors[(colorIndex++) % 6]);
            g2.fill(s);
        }

        if (startDrag != null && endDrag != null) {
            g2.setPaint(Color.BLACK);
            Object r = makeShape(startDrag.x, startDrag.y, endDrag.x, endDrag.y);
            if(r instanceof Shape) {
                g2.draw((Shape) r);
            } else {
                for(Shape s : (ArrayList<Shape>)r) {
                    g2.draw(s);
                }
            }
        }
    }


    private Object makeShape(int x1, int y1, int x2, int y2) {
        switch (this.shape) {
            case RECTANGLE:
                return makeRectangle(x1, y1, x2, y2);
            case CIRCLE:
                return makeCircle(x1, y1, x2, y2);
            case LINE:
                return makeLine(x1, y1, x2, y2);
            case ARROW:
                return makeArrow(x1, y1, x2, y2);
            default:
                return null;
        }
    }

    private Rectangle2D.Float makeRectangle(int x1, int y1, int x2, int y2) {
        return new Rectangle2D.Float(Math.min(x1, x2), Math.min(y1, y2), Math.abs(x1 - x2), Math.abs(y1 - y2));
    }

    private Ellipse2D.Float makeCircle(int x1, int y1, int x2, int y2) {
        return new Ellipse2D.Float(Math.min(x1, x2), Math.min(y1, y2), Math.abs(x1 - x2), Math.abs(y1 - y2));
    }

    private Line2D.Float makeLine(int x1, int y1, int x2, int y2) {
        return new Line2D.Float(x1, y1, x2, y2);
    }

    private ArrayList<Shape> makeArrow(int x1, int y1, int x2, int y2) {
        int deltaX = x2 - x1;
        int deltaY = y2 - y1;

        double rotation = 0f;
        rotation = -Math.atan2(deltaX, deltaY);
        rotation = Math.toDegrees(rotation) + 180;
        ArrowHead arrowHead = new ArrowHead();
        Rectangle bounds = arrowHead.getBounds();

        AffineTransform at = new AffineTransform();
        at.translate(x2  - (bounds.width / 2), y2 - (bounds.height / 2));
        at.rotate(Math.toRadians(rotation), bounds.width / 2, bounds.height / 2);
        Shape shape = new Path2D.Float(arrowHead, at);

        ArrayList<Shape> response = new ArrayList<>();
        response.add(makeLine(x1,y1,x2 ,y2));
        response.add(shape);
        return response;
    }


}

