package ro.idp.dashboard.ui.components;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.ArrayList;

/**
 * Created by Enti on 2/23/2016.
 */
public class UserPanel extends JPanel {

    DefaultListModel listOfUsers = new DefaultListModel();

    public UserPanel() {
        initUI();
    }

    private void initUI() {
        setSize(300, 180);
        JList users = new JList(listOfUsers);
        JScrollPane scrollPane = new JScrollPane(users);
        scrollPane.setBounds(10, 10, 290, 160);
        add(scrollPane);
        setLayout(null);
        setVisible(true);
        String[] sampleUsers = {"user1", "user2", "user3"};
        for(int i = 0; i < sampleUsers.length; i++) {
            addUser(sampleUsers[i]);
        }
    }

    public void addUser(String user) {
        listOfUsers.addElement(user);
    }

    public void removeUser(String user) {
        listOfUsers.removeElement(user);
    }

    private void refresh() {
        invalidate();
        validate();
        repaint();
    }
}
