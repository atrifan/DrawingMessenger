package ro.idp.dashboard.ui.components;

import javax.swing.*;
import java.awt.*;

/**
 * Created by Enti on 2/23/2016.
 */
public class Toolbar extends JPanel {
    JLabel helloMessage = new JLabel("Logged as: %s");
    JButton logout = new JButton("Log Out");
    JButton saveGroupWork = new JButton("Save Group Work");
    JButton createGroup = new JButton("Create Group");

    public Toolbar(String userName) {
        initUI(userName);
    }

    private void initUI(String userName) {
        setSize(420, 120);
        setLayout(null);
        String text = String.format(helloMessage.getText(), userName);
        helloMessage.setText(text);
        helloMessage.setBounds(160, 10, 110, 20);
        helloMessage.setHorizontalAlignment(SwingConstants.RIGHT);

        logout.setBounds(300, 10, 100, 20);
        saveGroupWork.setBounds(40, 60, 180, 20);
        createGroup.setBounds(40 + saveGroupWork.getWidth() + 10, 60, 110, 20);
        add(helloMessage);
        add(logout);
        add(saveGroupWork);
        add(createGroup);
        setVisible(true);
    }
}
